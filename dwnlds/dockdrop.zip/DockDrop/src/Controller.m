//
//  Controller.m
//  DockDrop
//
//  Created by Matthieu Cormier on 23/08/08.
//

#import "Controller.h"


@implementation Controller

- (id) init {
  if ((self = [super init])) {
    [NSApp setDelegate: self];    
  }
  
  return self;
}


- (void) awakeFromNib { }

- (void) applicationDidFinishLaunching: (NSNotification *) notification {
    
/*  To register for dock icon drags we need to set an event handler for the 
  kAEOpenContents and add the following to the info.plist file.
 
<key>NSServices</key>
<array>
  <dict>
    <key>NSPortName</key>
    <string>DockDrop</string>
    <key>NSSendTypes</key>
    <array>
      <string>NSStringPboardType</string>
      <string>NSURLPboardType</string>
    </array>
  </dict>
</array>
*/  
  
  // kAEOpenContents
  // Event that provides an application with dragged content, such as text or an image. Sent, for 
  // example, when a user drags an image file onto your application’s icon in the Dock. The 
  // application can use the content as desired—for example, if no document is currently open, 
  // it might open a new document and insert the provided text or image.
  [[NSAppleEventManager sharedAppleEventManager] setEventHandler: self
                                                     andSelector: @selector(handleOpenContentsEvent:replyEvent:)
                                                   forEventClass: kCoreEventClass andEventID: kAEOpenContents];  
  
}


/*
 To recieve file drags from the Finder onto the dock, set this class as the applications delegate, (this 
 is done in the init method), and add the following to info.plist
 
<key>CFBundleDocumentTypes</key>
<array>
  <dict>
    <key>CFBundleTypeExtensions</key>
    <array>
      <string>*</string>
    </array>
    <key>CFBundleTypeName</key>
    <string>Plain Text File</string>
    <key>CFBundleTypeOSTypes</key>
    <array>
      <string>****</string>
    </array>
    <key>CFBundleTypeRole</key>
    <string>Editor</string>
  </dict>
</array>
 
 */
- (void) application: (NSApplication *) app openFiles: (NSArray *) filenames {
  NSLog(@"Received a request to open the following files... ");
  for( NSString* filename in filenames ) {
    NSLog(@"TODO, do somemthing with %@", filename);
  }
}


- (void) handleOpenContentsEvent: (NSAppleEventDescriptor *) event replyEvent: (NSAppleEventDescriptor *) replyEvent {
  
  NSLog(@"handleOpenContentsEvent");
  
  NSString * urlString = nil;
  
  NSAppleEventDescriptor * directObject = [event paramDescriptorForKeyword: keyDirectObject];
  if ([directObject descriptorType] == typeAEList) {
    unsigned i;
    for (i = 1; i <= [directObject numberOfItems]; i++)
      if ((urlString = [[directObject descriptorAtIndex: i] stringValue]))
        break;
  }
  else
    urlString = [directObject stringValue];
  
  if (urlString) {    
    NSLog(@"urlString --> %@", urlString); 
  }
  
  return;
}  


@end
