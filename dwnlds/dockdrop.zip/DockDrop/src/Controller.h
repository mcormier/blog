//
//  Controller.h
//  DockDrop
//
//  Created by Matthieu Cormier on 23/08/08.
//

#import <Cocoa/Cocoa.h>


@interface Controller : NSObject {
  IBOutlet NSWindow* mainWindow;
  
}

@end
