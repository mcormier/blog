//
//  main.m
//  DockDrop
//
//  Created by Matthieu Cormier on 23/08/08.
//  Copyright Allusions Software 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
